/// <reference types="vite/client" />

declare module 'resize-base64'

