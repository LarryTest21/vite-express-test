<script setup lang="ts">

</script>


<template>
    <div class="rulebook">
      <h1>This is a rulebook page</h1>
    </div>
  </template>
  
  <style lang="scss">
  @media (min-width: 1024px) {
    .rulebook {
      height: 100%;
      display: flex;
      align-items: center;
      flex-direction: column;
      justify-content: center;
    }
  
  }
  </style>