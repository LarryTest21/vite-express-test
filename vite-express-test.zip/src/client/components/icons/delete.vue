<template>
    <svg xmlns="http://www.w3.org/2000/svg" id="Layer_1" data-name="Layer 1" viewBox="0 0 185.15 156.39">

        <circle class="delete-1" cx="92.58" cy="78.2" r="65.38" />
        <rect class="delete-2" x="82.9" y="34.11" width="19.35" height="88.17" rx="9.1" ry="9.1"
            transform="translate(82.41 -42.56) rotate(45)" />
        <rect class="delete-2" x="82.9" y="34.11" width="19.35" height="88.17" rx="9.1" ry="9.1"
            transform="translate(-28.18 88.36) rotate(-45)" />
</svg></template>>