<template>
<svg xmlns="http://www.w3.org/2000/svg" id="Layer_1" data-name="Layer 1" viewBox="0 0 185.15 156.39">

  <rect class="timer-2" x="88.18" y="22.89" width="14.52" height="24.26" rx="2.88" ry="2.88"/>
  <rect class="timer-2" x="89.77" y="8.6" width="11.33" height="28.58" rx="2.88" ry="2.88" transform="translate(118.32 -72.55) rotate(90)"/>
  <circle class="timer-1" cx="95.44" cy="92.55" r="46.4"/>
  <path class="timer-2" d="M118.53,93.9c0-2.01,1.63-3.63,3.63-3.63h8.69c-1.7-16.76-15.02-30.08-31.78-31.78v8.69c0,2.01-1.63,3.63-3.63,3.63s-3.63-1.63-3.63-3.63v-8.69c-16.76,1.7-30.08,15.02-31.78,31.78h8.69c2.01,0,3.63,1.63,3.63,3.63s-1.63,3.63-3.63,3.63h-8.69c1.7,16.76,15.02,30.08,31.78,31.78v-8.69c0-2.01,1.63-3.63,3.63-3.63s3.63,1.63,3.63,3.63v8.69c16.76-1.7,30.08-15.02,31.78-31.78h-8.69c-2.01,0-3.63-1.63-3.63-3.63Zm-13.15-5.06l-8.48,7.26c-1.53,1.31-3.83,1.13-5.14-.4-.04-.05-.07-.11-.11-.17l-15.15-17.71c-1.31-1.53-1.13-3.83,.4-5.14,1.53-1.31,3.83-1.13,5.14,.4l12.91,15.09,5.7-4.88c1.53-1.31,3.83-1.13,5.14,.4s1.13,3.83-.4,5.14Z"/>
  <rect class="timer-2" x="132.22" y="49.06" width="7.08" height="14.62" rx="2.88" ry="2.88" transform="translate(79.62 -79.48) rotate(45)"/>
  <rect class="timer-2" x="136.84" y="44.36" width="6.88" height="14.81" rx="2.88" ry="2.88" transform="translate(276.08 -10.83) rotate(135)"/>
</svg>
</template>
    <style>
      .timer-1 {
        fill: none;
        stroke: var(--color-nav-bg);
        stroke-miterlimit: 10;
        stroke-width: 9px;
      }

      .timer-2 {
        stroke:none;
        fill: var(--color-nav-bg);
      }
     
    </style>