<template>
  <svg
    width="10"
    height="10"
    viewBox="0 0 24 24"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g>
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        xmlns="http://www.w3.org/2000/svg"
        d="M12,2A10,10,0,1,0,22,12,10.011,10.011,0,0,0,12,2Zm0,18a8,8,0,1,1,8-8A8.009,8.009,0,0,1,12,20Z"
      />
      <polygon xmlns="http://www.w3.org/2000/svg" points="8.707 7.293 7.293 8.707 10.586 12 7.293 15.293 8.707 16.707 13.414 12 8.707 7.293"/>
      <polygon xmlns="http://www.w3.org/2000/svg" points="11.293 8.707 14.586 12 11.293 15.293 12.707 16.707 17.414 12 12.707 7.293 11.293 8.707"/>
    </g>
  </svg>
</template>
