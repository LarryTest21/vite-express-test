<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    id="Layer_1"
    data-name="Layer 1"
    viewBox="0 0 185.15 156.39"
  >
    <path
      class="eye-2"
      d="M92.58,47.15c-30.79,0-57.61,12.52-71.71,31.05,14.1,18.53,40.92,31.05,71.71,31.05s57.61-12.52,71.71-31.05c-14.1-18.53-40.92-31.05-71.71-31.05Z"
    />
    <circle class="eye-1" cx="102.56" cy="78.2" r="23.41" />
  </svg>
</template>

<style>

</style>
