<template>

<svg xmlns="http://www.w3.org/2000/svg" id="Layer_1" data-name="Layer 1" viewBox="0 0 185.15 156.39">
  <!-- <defs>
    <style>
      .cls-1 {
        letter-spacing: -.01em;
      }

      .cls-2 {
        fill: none;
        stroke: #231f20;
        stroke-miterlimit: 10;
        stroke-width: 5px;
      }

      .cls-3 {
        letter-spacing: .01em;
      }

      .cls-4 {
        letter-spacing: 0em;
      }

      .cls-5 {
        letter-spacing: -.03em;
      }

      .cls-6 {
        font-family: Nunito-ExtraBold, Nunito;
        font-size: 12px;
        font-weight: 700;
      }

      .cls-6, .cls-7 {
        fill: #231f20;
      }
    </style>
  </defs> -->
  <g>
    <path class="cls-7" d="M140.38,89.19c-2.66-2.42-6.3-2.01-8.62,.89-4.68,5.87-11.18,9.5-18.37,9.5s-13.69-3.64-18.37-9.5c-2.32-2.91-5.96-3.32-8.62-.89-9.4,8.55-16.06,21.44-18.05,36.29-.65,4.88,2.43,9.31,6.43,9.31h77.23c3.99,0,7.08-4.43,6.43-9.31-1.99-14.85-8.65-27.75-18.05-36.29Z"/>
    <circle class="cls-7" cx="113.39" cy="61.76" r="25.84"/>
    <rect class="cls-2" x="26.63" y="21.6" width="116.03" height="80.32" rx="8.26" ry="8.26"/>
  </g>
</svg>

</template>>